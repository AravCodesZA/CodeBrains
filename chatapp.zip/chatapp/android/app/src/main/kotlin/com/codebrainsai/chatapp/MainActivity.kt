package com.codebrainsai.chatapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
