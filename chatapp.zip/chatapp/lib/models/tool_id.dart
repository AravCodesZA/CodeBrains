// lib/models/tool_id.dart
enum ToolId {
  aiCoder,
  smartComplete,
  codeOptimizer,
  bugFinder,
  performance,
  codeReview,
}
