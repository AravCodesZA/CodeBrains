# CodeBrains Chat (Flutter)

**Name:** CodeBrains Chat  
**Package ID:** `com.codebrainsai.chatapp` (set during Android generation)  
**Platforms:** Android only

This zip contains the Dart code and `pubspec.yaml`. You'll generate the Android
platform files locally to ensure they match your Flutter version.

## 1) Unzip
Unzip anywhere (e.g. `C:\Users\YOURNAME\Projects\chatapp`).

## 2) Create Android platform with the correct package id
From the project root (the folder that contains `pubspec.yaml`), run:

```
flutter create --platforms=android --org com.codebrainsai .
```

Because the project directory is named **chatapp**, the resulting applicationId
will be **com.codebrainsai.chatapp**.

> If you get a message that files already exist, it's okay — Flutter will add the
> missing Android folder. It won't overwrite your Dart code.

## 3) Get packages
```
flutter pub get
```

## 4) Run on emulator or device
Start an Android emulator from Android Studio (API 30+ recommended), or connect a device,
then run:

```
flutter run
```

## API placeholder
- Edit `lib/api_service.dart` and replace `YOUR_API_KEY_HERE` with your key.
- Or pass it at build time:
```
flutter run --dart-define=CODEBRAINS_API_KEY=sk-xxx
```

## Notes
- Theme is a dark, Material 3 look matching your HTML mock.
- Chat screen includes typing indicator and quick suggestion chips.
